public abstract class Service extends Shower{
	public abstract String getDescription();
}

public class Bath extends Shower{
	public Bath(){
		description="��ԡ";
	}
	public int cost(){
		return 10;
	}
}
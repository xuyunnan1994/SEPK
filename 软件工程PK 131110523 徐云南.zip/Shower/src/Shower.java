public abstract class Shower {
	String description="Unknown";
	public abstract int cost();
	public String getDescription() {
		return description;
	}
}
